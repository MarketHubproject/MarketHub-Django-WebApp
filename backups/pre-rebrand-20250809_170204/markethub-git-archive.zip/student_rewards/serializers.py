from rest_framework import serializers
# Import your models here and create serializers
# Example:
# from .models import YourModel
# 
# class YourModelSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = YourModel
#         fields = '__all__'
